rpinfo 0.2.1 (2019.06.03)

Gathers platform information of the currently running Raspberry Pi.
Supports: Raspberry Pi A, A+, B, B+, 2B, 3B, 3B+, Zero, ZeroW, CM1 and CM3.

(C) 2018,2019 @TimothyBrown

MIT License
